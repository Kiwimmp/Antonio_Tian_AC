package Postgres.Model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
public class Objeto implements Serializable {

    // Enum para Rareza
    public enum Rareza {
        COMUN, POCO_COMUN, RARO, EPICO, LEGENDARIO
    }

    // Enum para TipoArma
    public enum TipoArma {
        MELEE, RANGO, BASTON
    }

    @Id
    @GeneratedValue
    private int id;

    @Column(name = "nombre")
    private String nombre;

    @Enumerated(EnumType.STRING)
    private Rareza rareza;

    @Enumerated(EnumType.STRING)
    private TipoArma tipo;

    //Constructor
    public Objeto() {
    }

    public Objeto(int id, String nombre, Rareza rareza, TipoArma tipo) {
        this.id = id;
        this.nombre = nombre;
        this.rareza = rareza;
        this.tipo = tipo;
    }
    //Getter y setter

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Rareza getRareza() {
        return rareza;
    }

    public void setRareza(Rareza rareza) {
        this.rareza = rareza;
    }

    public TipoArma getTipo() {
        return tipo;
    }

    public void setTipo(TipoArma tipo) {
        this.tipo = tipo;
    }

}
