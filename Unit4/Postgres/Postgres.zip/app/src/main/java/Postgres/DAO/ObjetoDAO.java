package Postgres.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import Postgres.Model.Objeto;
import java.util.List;
import java.util.Scanner;

/**
 * Clase que maneja las operaciones CRUD para la entidad Objeto en la base de
 * datos.
 */
public class ObjetoDAO {

    private final EntityManager entityManager;
    private final Scanner scanner;

    /**
     * Constructor de la clase ObjetoDAO.
     */
    public ObjetoDAO() {
        entityManager = Persistence.createEntityManagerFactory("juego_rol").createEntityManager();
        scanner = new Scanner(System.in);
    }

    /**
     * Cierra el EntityManager cuando ya no es necesario.
     */
    public void closeEntityManager() {
        entityManager.close();
    }

    /**
     * Muestra el menú de operaciones para la entidad Objeto.
     */
    public void mostrarmenu() {
        boolean exit = false;

        while (!exit) {
            System.out.println("----- Menú de Operaciones de Objetos -----");
            System.out.println("1. Crear Objeto");
            System.out.println("2. Consultar Objetos");
            System.out.println("3. Actualizar Objeto");
            System.out.println("4. Eliminar Objeto");
            System.out.println("5. Volver al Menú Principal");

            System.out.print("Seleccione una opción: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1 ->
                    crearObjeto();
                case 2 ->
                    consultarObjetos();
                case 3 ->
                    actualizarObjeto();
                case 4 ->
                    eliminarObjeto();
                case 5 ->
                    exit = true;
                default ->
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }

    /**
     * Crea un nuevo objeto y lo guarda en la base de datos.
     */
    private void crearObjeto() {
        scanner.nextLine(); // Consumir el salto de línea pendiente
        System.out.println("Ingrese el nombre del objeto: ");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese el tipo del objeto (Melee, Rango, Bastón): ");
        String tipoStr = scanner.nextLine();

        System.out.println("Ingrese la rareza del objeto (Común, Poco Común, Raro, Épico, Legendario): ");
        String rarezaStr = scanner.nextLine();

        Objeto.TipoArma tipo = Objeto.TipoArma.valueOf(tipoStr.toUpperCase());
        Objeto.Rareza rareza = Objeto.Rareza.valueOf(rarezaStr.toUpperCase());

        Objeto nuevoObjeto = new Objeto();
        nuevoObjeto.setNombre(nombre);
        nuevoObjeto.setTipo(tipo);
        nuevoObjeto.setRareza(rareza);

        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        entityManager.persist(nuevoObjeto);
        transaction.commit();

        System.out.println("Objeto creado con éxito.");
    }

    /**
     * Consulta y muestra todos los objetos almacenados en la base de datos.
     */
    private void consultarObjetos() {
        List<Objeto> objetos = entityManager.createQuery("SELECT o FROM Objeto o", Objeto.class).getResultList();
        for (Objeto objeto : objetos) {
            System.out.println(objeto);
        }
    }

    /**
     * Actualiza un objeto existente en la base de datos.
     */
    private void actualizarObjeto() {
        System.out.println("Ingrese el ID del objeto a actualizar: ");
        int idObjeto = scanner.nextInt();

        // Verificar si el objeto con el ID proporcionado existe en la base de datos
        Objeto objeto = entityManager.find(Objeto.class, idObjeto);

        if (objeto != null) {
            scanner.nextLine(); // Consumir el salto de línea pendiente
            System.out.println("Ingrese el nuevo nombre del objeto: ");
            String nuevoNombre = scanner.nextLine();

            System.out.println("Ingrese el nuevo tipo del objeto (Melee, Rango, Bastón): ");
            String tipoStr = scanner.nextLine();

            System.out.println("Ingrese la nueva rareza del objeto (Común, Poco Común, Raro, Épico, Legendario): ");
            String rarezaStr = scanner.nextLine();

            Objeto.TipoArma nuevoTipo = Objeto.TipoArma.valueOf(tipoStr.toUpperCase());
            Objeto.Rareza nuevaRareza = Objeto.Rareza.valueOf(rarezaStr.toUpperCase());

            // Actualizar los atributos del objeto
            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            objeto.setNombre(nuevoNombre);
            objeto.setTipo(nuevoTipo);
            objeto.setRareza(nuevaRareza);
            transaction.commit();

            System.out.println("Objeto actualizado con éxito.");
        } else {
            System.out.println("Objeto no encontrado. Verifique el ID e intente nuevamente.");
        }
    }

    /**
     * Elimina un objeto de la base de datos.
     */
    private void eliminarObjeto() {
        System.out.println("Ingrese el ID del objeto a eliminar: ");
        int idObjeto = scanner.nextInt();

        // Verificar si el objeto con el ID proporcionado existe en la base de datos
        Objeto objeto = entityManager.find(Objeto.class, idObjeto);

        if (objeto != null) {
            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.remove(objeto);
            transaction.commit();

            System.out.println("Objeto eliminado con éxito.");
        } else {
            System.out.println("Objeto no encontrado. Verifique el ID e intente nuevamente.");
        }
    }

}
