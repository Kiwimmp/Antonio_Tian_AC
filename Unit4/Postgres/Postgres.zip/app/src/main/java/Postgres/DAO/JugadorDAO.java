package Postgres.DAO;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Scanner;
import Postgres.Model.Jugador;

public class JugadorDAO {

    private final EntityManager entityManager;
    private final Scanner scanner;

    public JugadorDAO(EntityManager entityManager, Scanner scanner) {
        this.entityManager = entityManager;
        this.scanner = scanner;
    }

    public void mostrarMenu() {
        boolean exit = false;

        while (!exit) {
            System.out.println("----- Menú Jugadores -----");
            System.out.println("1. Crear Jugador");
            System.out.println("2. Consultar Jugadores");
            System.out.println("3. Actualizar Jugador");
            System.out.println("4. Eliminar Jugador");
            System.out.println("5. Volver al Menú Principal");

            System.out.print("Seleccione una opción: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1 -> crearJugador();
                case 2 -> consultarJugadores();
                case 3 -> actualizarJugador();
                case 4 -> eliminarJugador();
                case 5 -> exit = true;
                default -> System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }

    private void crearJugador() {
        scanner.nextLine(); // Consumir el salto de línea pendiente
        System.out.println("Ingrese el nombre del jugador: ");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese el correo del jugador: ");
        String correo = scanner.nextLine();

        Jugador nuevoJugador = new Jugador();
        nuevoJugador.setNombre(nombre);
        nuevoJugador.setCorreo(correo);
        entityManager.getTransaction().begin();
        entityManager.persist(nuevoJugador);
        entityManager.getTransaction().commit();
        System.out.println("Jugador creado con éxito.");
    }

    private void consultarJugadores() {
        List<Jugador> jugadores = entityManager.createQuery("SELECT j FROM Jugador j", Jugador.class).getResultList();
        for (Jugador jugador : jugadores) {
            System.out.println(jugador);
        }
    }

    private void actualizarJugador() {
        System.out.println("Ingrese el ID del jugador a actualizar: ");
        int idJugador = scanner.nextInt();

        // Verificar si el jugador con el ID proporcionado existe en la base de datos
        Jugador jugador = entityManager.find(Jugador.class, idJugador);

        if (jugador != null) {
            scanner.nextLine(); // Consumir el salto de línea pendiente
            System.out.println("Ingrese el nuevo nombre del jugador: ");
            String nuevoNombre = scanner.nextLine();

            System.out.println("Ingrese el nuevo correo del jugador: ");
            String nuevoCorreo = scanner.nextLine();

            // Actualizar los atributos del jugador
            entityManager.getTransaction().begin();
            jugador.setNombre(nuevoNombre);
            jugador.setCorreo(nuevoCorreo);
            entityManager.getTransaction().commit();

            System.out.println("Jugador actualizado con éxito.");
        } else {
            System.out.println("Jugador no encontrado. Verifique el ID e intente nuevamente.");
        }
    }

    private void eliminarJugador() {
        System.out.println("Ingrese el ID del jugador a eliminar: ");
        int idJugador = scanner.nextInt();

        // Verificar si el jugador con el ID proporcionado existe en la base de datos
        Jugador jugador = entityManager.find(Jugador.class, idJugador);

        if (jugador != null) {
            // Eliminar el jugador de la base de datos
            entityManager.getTransaction().begin();
            entityManager.remove(jugador);
            entityManager.getTransaction().commit();

            System.out.println("Jugador eliminado con éxito.");
        } else {
            System.out.println("Jugador no encontrado. Verifique el ID e intente nuevamente.");
        }
    }
}
