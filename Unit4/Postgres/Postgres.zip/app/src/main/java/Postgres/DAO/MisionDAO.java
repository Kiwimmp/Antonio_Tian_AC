package Postgres.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;
import java.util.Scanner;

import Postgres.Model.Mision;

/**
 * Clase que maneja las operaciones CRUD para la entidad Mision en la base de datos.
 */
public class MisionDAO {

    private final EntityManager entityManager;
    private final Scanner scanner;

    /**
     * Constructor de la clase MisionDAO.
     */
    public MisionDAO() {
        this.entityManager = Persistence.createEntityManagerFactory("juego_rol").createEntityManager();
        this.scanner = new Scanner(System.in);
    }

    /**
     * Cierra el EntityManager al finalizar su uso.
     */
    public void closeEntityManager() {
        entityManager.close();
    }

    /**
     * Muestra el menú de operaciones para la entidad Mision.
     */
    public void mostrarMenu() {
        boolean exitMenu = false;

        while (!exitMenu) {
            System.out.println("----- Menú Misiones -----");
            System.out.println("1. Crear Misión");
            System.out.println("2. Consultar Misiones");
            System.out.println("3. Actualizar Misión");
            System.out.println("4. Eliminar Misión");
            System.out.println("5. Volver al Menú Principal");

            System.out.print("Seleccione una opción: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1 ->
                    crearMision();
                case 2 ->
                    consultarMisiones();
                case 3 ->
                    actualizarMision();
                case 4 ->
                    eliminarMision();
                case 5 ->
                    exitMenu = true;
                default ->
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }

    /**
     * Crea una nueva misión y la guarda en la base de datos.
     */
    private void crearMision() {
        scanner.nextLine(); // Consumir el salto de línea pendiente
        System.out.println("Ingrese el nombre de la misión: ");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese el tipo de la misión: ");
        String tipo = scanner.nextLine();

        System.out.println("Ingrese la dificultad de la misión: ");
        String dificultad = scanner.nextLine();

        Mision nuevaMision = new Mision();
        nuevaMision.setNombre(nombre);
        nuevaMision.setTipo(tipo);
        nuevaMision.setDificultad(dificultad);

        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        entityManager.persist(nuevaMision);
        transaction.commit();

        System.out.println("Misión creada con éxito.");
    }

    /**
     * Consulta y muestra todas las misiones almacenadas en la base de datos.
     */
    private void consultarMisiones() {
        TypedQuery<Mision> query = entityManager.createQuery("SELECT m FROM Mision m", Mision.class);
        List<Mision> misiones = query.getResultList();

        System.out.println("----- Misiones -----");
        for (Mision mision : misiones) {
            System.out.println(mision);
        }
    }

    /**
     * Actualiza una misión existente en la base de datos.
     */
    private void actualizarMision() {
        System.out.println("Ingrese el ID de la misión a actualizar: ");
        int idMision = scanner.nextInt();

        // Verificar si la misión con el ID proporcionado existe en la base de datos
        Mision mision = entityManager.find(Mision.class, idMision);

        if (mision != null) {
            scanner.nextLine(); // Consumir el salto de línea pendiente
            System.out.println("Ingrese el nuevo nombre de la misión: ");
            String nuevoNombre = scanner.nextLine();

            System.out.println("Ingrese el nuevo tipo de la misión: ");
            String nuevoTipo = scanner.nextLine();

            System.out.println("Ingrese la nueva dificultad de la misión: ");
            String nuevaDificultad = scanner.nextLine();

            // Actualizar los atributos de la misión
            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            mision.setNombre(nuevoNombre);
            mision.setTipo(nuevoTipo);
            mision.setDificultad(nuevaDificultad);
            transaction.commit();

            System.out.println("Misión actualizada con éxito.");
        } else {
            System.out.println("Misión no encontrada. Verifique el ID e intente nuevamente.");
        }
    }

    /**
     * Elimina una misión de la base de datos.
     */
    private void eliminarMision() {
        System.out.println("Ingrese el ID de la misión a eliminar: ");
        int idMision = scanner.nextInt();

        // Verificar si la misión con el ID proporcionado existe en la base de datos
        Mision mision = entityManager.find(Mision.class, idMision);

        if (mision != null) {
            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.remove(mision);
            transaction.commit();

            System.out.println("Misión eliminada con éxito.");
        } else {
            System.out.println("Misión no encontrada. Verifique el ID e intente nuevamente.");
        }
    }
}
