package Postgres.Model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
public class Personaje implements Serializable {

    public enum Clase_personaje {
        MELEE, RANGO, ARCANE
    }
    @Id
    @GeneratedValue
    private int id;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "nivel")
    private int nivel;

    @Enumerated(EnumType.STRING)
    private Clase_personaje clase;

    @ManyToOne
    @JoinColumn(name = "jugador_id")
    private Jugador jugador;

    @Embedded
    private AtributosPersonaje atributos;

    //Constructor
    public Personaje() {
    }

    public Personaje(int id, String nombre, int nivel, Clase_personaje clase, Jugador jugador, AtributosPersonaje atributos) {
        this.id = id;
        this.nombre = nombre;
        this.nivel = nivel;
        this.clase = clase;
        this.jugador = jugador;
        this.atributos = atributos;
    }

    public Personaje(String nombre, int nivel, Clase_personaje clase) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.clase = clase;
    }


    
    
    //Getter y setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public Clase_personaje getClase() {
        return clase;
    }

    public void setClase(Clase_personaje clase) {
        this.clase = clase;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public AtributosPersonaje getAtributos() {
        return atributos;
    }

    public void setAtributos(AtributosPersonaje atributos) {
        this.atributos = atributos;
    }

}
