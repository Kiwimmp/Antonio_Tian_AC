package Postgres.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Scanner;

public class DAO {

    private final EntityManagerFactory entityManagerFactory;
    private final EntityManager entityManager;
    private final Scanner scanner;

    public DAO() {
        entityManagerFactory = Persistence.createEntityManagerFactory("juego_rol");
        entityManager = entityManagerFactory.createEntityManager();
        scanner = new Scanner(System.in);
    }

    public void closeEntityManager() {
        entityManager.close();
        entityManagerFactory.close();
    }

    public void mostrarmenu() {
        try (scanner) {
            boolean exit = false;

            while (!exit) {
                System.out.println("----- Menú de Consultas -----");
                System.out.println("1. Menú Jugadores");
                System.out.println("2. Menú Personajes");
                System.out.println("3. Menú Objetos");
                System.out.println("4. Menú Misiones");
                System.out.println("5. Salir");

                System.out.print("Seleccione una opción: ");
                int option = scanner.nextInt();

                switch (option) {
                    case 1 ->
                        menuJugadores();
                    case 2 ->
                        menuPersonajes();
                    case 3 ->
                        menuObjetos();
                    case 4 ->
                        menuMisiones();
                    case 5 ->
                        exit = true;
                    default ->
                        System.out.println("Opción no válida. Intente de nuevo.");
                }
            }
        }

    }

    private void menuJugadores() {
        JugadorDAO jugadorDAO = new JugadorDAO(entityManager, scanner);
        jugadorDAO.mostrarMenu();
    }

    private void menuPersonajes() {
        PersonajeDAO personajeDAO = new PersonajeDAO();
        personajeDAO.mostrarMenu();
    }

    private void menuObjetos() {
        ObjetoDAO objetoDAO = new ObjetoDAO();
        objetoDAO.mostrarmenu();
    }

    private void menuMisiones() {
        MisionDAO misionDAO = new MisionDAO();
        misionDAO.mostrarMenu();
    }
}
