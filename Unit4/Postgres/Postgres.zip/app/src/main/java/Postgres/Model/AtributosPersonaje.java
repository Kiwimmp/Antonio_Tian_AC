package Postgres.Model;

import java.io.Serializable;
import javax.persistence.Embeddable;


@Embeddable
public class AtributosPersonaje implements Serializable {

    private int vida = 100;
    private int mana = 30;
    private int ataque = 10;
    private int defensa = 10;
    private int velocidadMovimiento = 10;
    private int velocidadAtaque = 1;
    //Constructor

    public AtributosPersonaje() {
    }

    //Getter y setter
    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getMana() {
        return mana;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getDefensa() {
        return defensa;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }

    public int getVelocidadMovimiento() {
        return velocidadMovimiento;
    }

    public void setVelocidadMovimiento(int velocidadMovimiento) {
        this.velocidadMovimiento = velocidadMovimiento;
    }

    public int getVelocidadAtaque() {
        return velocidadAtaque;
    }

    public void setVelocidadAtaque(int velocidadAtaque) {
        this.velocidadAtaque = velocidadAtaque;
    }
    /**
     * Funcion que cambie la estadistica de los roles según el nivel asignado
     * @param nivel 
     */
    public void actualizarAtributosSegunNivel(int nivel) {
        vida = 100 + (nivel * 30);
        mana = 30 + (nivel * 5);
        ataque = 10 + nivel;
        defensa = 10 + nivel;
        velocidadAtaque = 1 + nivel;
        velocidadMovimiento = 10 + nivel;
    }

}
