package Postgres.Model;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Guerrero extends Personaje {

    @Column(name = "arma")
    private String arma;

    public Guerrero() {

    }

    public Guerrero(String nombre, int nivel, Clase_personaje clase, String arma) {
        super(nombre, nivel, clase);
        this.arma = arma;
    }

    public String getArma() {
        return arma;
    }

    public void setArma(String arma) {
        this.arma = arma;
    }
}
