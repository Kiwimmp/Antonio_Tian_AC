package Postgres.DAO;

import Postgres.Model.AtributosPersonaje;
import Postgres.Model.Personaje;
import Postgres.Model.Guerrero;
import Postgres.Model.Mago;
import Postgres.Model.Tirador;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.List;
import java.util.Scanner;

/**
 * Clase que maneja las operaciones CRUD para la entidad Personaje en la base de
 * datos.
 */
public class PersonajeDAO {

    private final EntityManager entityManager;
    private final Scanner scanner;

    /**
     * Constructor de la clase PersonajeDAO.
     */
    public PersonajeDAO() {
        this.entityManager = Persistence.createEntityManagerFactory("juego_rol").createEntityManager();
        this.scanner = new Scanner(System.in);
    }

    /**
     * Cierra el EntityManager cuando ya no es necesario.
     */
    public void closeEntityManager() {
        entityManager.close();
    }

    /**
     * Muestra el menú de operaciones para la entidad Personaje.
     */
    public void mostrarMenu() {
        boolean exitMenu = false;

        while (!exitMenu) {
            System.out.println("----- Menú Personajes -----");
            System.out.println("1. Crear Personaje");
            System.out.println("2. Consultar Personajes");
            System.out.println("3. Actualizar Personaje");
            System.out.println("4. Eliminar Personaje");
            System.out.println("5. Crear Roles");
            System.out.println("6. Volver al Menú Principal");

            System.out.print("Seleccione una opción: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1 ->
                    crearPersonaje();
                case 2 ->
                    consultarPersonajes();
                case 3 ->
                    actualizarPersonaje();
                case 4 ->
                    eliminarPersonaje();
                case 5 ->
                    crearRoles();
                case 6 ->
                    exitMenu = true;
                default ->
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }

    /**
     * Función para crear un nuevo personaje.
     */
    private void crearPersonaje() {
        scanner.nextLine();

        System.out.println("Ingrese el nombre del personaje: ");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese el nivel del personaje: ");
        int nivel = scanner.nextInt();

        System.out.println("Seleccione la clase del personaje (Melee/Rango/Arcane): ");
        String claseStr = scanner.next();

        try {
            Personaje.Clase_personaje clase = Personaje.Clase_personaje.valueOf(claseStr.toUpperCase());

            // Crear instancia de AtributosPersonaje y actualizar atributos según el nivel
            AtributosPersonaje atributosPersonaje = new AtributosPersonaje();
            atributosPersonaje.actualizarAtributosSegunNivel(nivel);

            // Crear instancia de Personaje
            Personaje nuevoPersonaje = new Personaje();
            nuevoPersonaje.setNombre(nombre);
            nuevoPersonaje.setNivel(nivel);
            nuevoPersonaje.setClase(clase);
            nuevoPersonaje.setAtributos(atributosPersonaje);

            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.persist(nuevoPersonaje);
            transaction.commit();

            System.out.println("Personaje creado con éxito.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: Clase de personaje no válida. Intente nuevamente.");
        }
    }

    /**
     * Función para mostrar toda la lista de personajes creados.
     */
    private void consultarPersonajes() {
        TypedQuery<Personaje> query = entityManager.createQuery("SELECT p FROM Personaje p", Personaje.class);
        List<Personaje> personajes = query.getResultList();

        System.out.println("----- Personajes -----");
        for (Personaje personaje : personajes) {
            System.out.println(personaje);
        }
    }

    /**
     * Función que permite cambiar el nombre y el nivel del personaje.
     */
    private void actualizarPersonaje() {
        System.out.println("Ingrese el ID del personaje a actualizar: ");
        int idPersonaje = scanner.nextInt();

        Personaje personaje = entityManager.find(Personaje.class, idPersonaje);

        if (personaje != null) {
            scanner.nextLine();
            System.out.println("Ingrese el nuevo nombre del personaje: ");
            String nuevoNombre = scanner.nextLine();

            System.out.println("Ingrese el nuevo nivel del personaje: ");
            int nuevoNivel = scanner.nextInt();

            personaje.setNombre(nuevoNombre);
            personaje.setNivel(nuevoNivel);

            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.merge(personaje);
            transaction.commit();

            System.out.println("Personaje actualizado con éxito.");
        } else {
            System.out.println("Personaje no encontrado. Verifique el ID e intente nuevamente.");
        }
    }

    /**
     * Función que elimina el personaje, buscando su ID y eliminando también los
     * roles asociados a él.
     */
    private void eliminarPersonaje() {
        System.out.println("Ingrese el ID del personaje a eliminar: ");
        int idPersonaje = scanner.nextInt();

        // Verificar si el personaje con el ID proporcionado existe en la base de datos
        Personaje personaje = entityManager.find(Personaje.class, idPersonaje);

        if (personaje != null) {
            // Eliminar roles asociados (Guerrero, Mago, Tirador) si existen
            eliminarRolGuerrero(idPersonaje);
            eliminarRolMago(idPersonaje);
            eliminarRolTirador(idPersonaje);

            // Eliminar el personaje de la base de datos
            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.remove(personaje);
            transaction.commit();

            System.out.println("Personaje y roles asociados eliminados con éxito.");
        } else {
            System.out.println("Personaje no encontrado. Verifique el ID e intente nuevamente.");
        }
    }

    /**
     * Elimina el rol de Guerrero asociado al personaje.
     *
     * @param idPersonaje ID del personaje.
     */
    private void eliminarRolGuerrero(int idPersonaje) {
        Guerrero guerrero = entityManager.find(Guerrero.class, idPersonaje);
        if (guerrero != null) {
            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.remove(guerrero);
            transaction.commit();
            System.out.println("Rol Guerrero eliminado con éxito.");
        }
    }

    /**
     * Elimina el rol de Mago asociado al personaje.
     *
     * @param idPersonaje ID del personaje.
     */
    private void eliminarRolMago(int idPersonaje) {
        Mago mago = entityManager.find(Mago.class, idPersonaje);
        if (mago != null) {
            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.remove(mago);
            transaction.commit();
            System.out.println("Rol Mago eliminado con éxito.");
        }
    }

    /**
     * Elimina el rol de Tirador asociado al personaje.
     *
     * @param idPersonaje ID del personaje.
     */
    private void eliminarRolTirador(int idPersonaje) {
        Tirador tirador = entityManager.find(Tirador.class, idPersonaje);
        if (tirador != null) {
            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.remove(tirador);
            transaction.commit();
            System.out.println("Rol Tirador eliminado con éxito.");
        }
    }

    /**
     * Muestra el menú para crear roles asociados a los personajes.
     */
    private void crearRoles() {
        boolean exitMenuRoles = false;

        while (!exitMenuRoles) {
            System.out.println("----- Menú Crear Roles -----");
            System.out.println("1. Crear Guerrero");
            System.out.println("2. Crear Mago");
            System.out.println("3. Crear Tirador");
            System.out.println("4. Volver al Menú Personajes");

            System.out.print("Seleccione una opción: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1 ->
                    crearGuerrero();
                case 2 ->
                    crearMago();
                case 3 ->
                    crearTirador();
                case 4 ->
                    exitMenuRoles = true;
                default ->
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }

    /**
     * Crea un nuevo rol de Guerrero asociado a un personaje.
     */
    private void crearGuerrero() {
        System.out.println("Ingrese el ID del personaje para asignar como Guerrero: ");
        int idPersonaje = scanner.nextInt();

        // Verificar si el personaje con el ID proporcionado existe en la base de datos
        Personaje personaje = entityManager.find(Personaje.class, idPersonaje);

        if (personaje != null && personaje.getClase() == Personaje.Clase_personaje.MELEE) {
            scanner.nextLine(); // Consumir el salto de línea pendiente
            System.out.println("Ingrese el arma del Guerrero: ");
            String armaGuerrero = scanner.nextLine();

            Guerrero guerrero = new Guerrero();
            guerrero.setId(idPersonaje);
            guerrero.setArma(armaGuerrero);

            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.persist(guerrero);
            transaction.commit();

            System.out.println("Guerrero creado con éxito.");
        } else {
            System.out.println("Personaje no encontrado o no es de clase MELEE. Verifique el ID e intente nuevamente.");
        }
    }

    /**
     * Crea un nuevo rol de Mago asociado a un personaje.
     */
    private void crearMago() {
        System.out.println("Ingrese el ID del personaje para asignar como Mago: ");
        int idPersonaje = scanner.nextInt();

        // Verificar si el personaje con el ID proporcionado existe en la base de datos
        Personaje personaje = entityManager.find(Personaje.class, idPersonaje);

        if (personaje != null && personaje.getClase() == Personaje.Clase_personaje.ARCANE) {
            scanner.nextLine(); // Consumir el salto de línea pendiente
            System.out.println("Ingrese el bastón del Mago: ");
            String bastonMago = scanner.nextLine();

            Mago mago = new Mago();
            mago.setId(idPersonaje);
            mago.setArma(bastonMago);

            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.persist(mago);
            transaction.commit();

            System.out.println("Mago creado con éxito.");
        } else {
            System.out.println("Personaje no encontrado o no es de clase ARCANE. Verifique el ID e intente nuevamente.");
        }
    }
    /**
     * Crea un nuevo rol de Tirador asociado a un personaje.
     */
    private void crearTirador() {
        System.out.println("Ingrese el ID del personaje para asignar como Tirador: ");
        int idPersonaje = scanner.nextInt();

        // Verificar si el personaje con el ID proporcionado existe en la base de datos
        Personaje personaje = entityManager.find(Personaje.class, idPersonaje);

        if (personaje != null && personaje.getClase() == Personaje.Clase_personaje.RANGO) {
            scanner.nextLine(); // Consumir el salto de línea pendiente
            System.out.println("Ingrese el arco del Tirador: ");
            String arcoTirador = scanner.nextLine();

            Tirador tirador = new Tirador();
            tirador.setId(idPersonaje);
            tirador.setArma(arcoTirador);

            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            entityManager.persist(tirador);
            transaction.commit();

            System.out.println("Tirador creado con éxito.");
        } else {
            System.out.println("Personaje no encontrado o no es de clase RANGO. Verifique el ID e intente nuevamente.");
        }
    }

}
