package Postgres.Model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
public class Jugador implements Serializable {

    @Id
    @GeneratedValue
    private int id;
    
    @Column(name = "nombre")
    private String nombre;
    
    @Column(name = "correo")
    private String correo;

    @Embedded
    private Direccion direccionJugador;
    //Constructor

    public Jugador() {
    }

    public Jugador(int id, String nombre, String correo, Direccion direccionJugador) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.direccionJugador = direccionJugador;
    }

    //Getter y setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public Direccion getDireccionJugador() {
        return direccionJugador;
    }

    public void setDireccionJugador(Direccion direccionJugador) {
        this.direccionJugador = direccionJugador;
    }

}
