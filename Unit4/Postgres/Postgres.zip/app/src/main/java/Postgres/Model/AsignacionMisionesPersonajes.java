package Postgres.Model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "asignacion_misiones_personajes")
public class AsignacionMisionesPersonajes implements Serializable {

    @Id
    @ManyToOne
    @JoinColumn(name = "personaje_id")
    private Personaje personaje;

    @Id
    @ManyToOne
    @JoinColumn(name = "mision_id")
    private Mision mision;

    @Column(name = "completada")
    private boolean completada;

    // Constructor

    public AsignacionMisionesPersonajes() {
    }
    


    public AsignacionMisionesPersonajes(Personaje personaje, Mision mision, boolean completada) {
        this.personaje = personaje;
        this.mision = mision;
        this.completada = completada;
    }
    //Getter y setter

    public Personaje getPersonaje() {
        return personaje;
    }

    public void setPersonaje(Personaje personaje) {
        this.personaje = personaje;
    }

    public Mision getMision() {
        return mision;
    }

    public void setMision(Mision mision) {
        this.mision = mision;
    }

    public boolean isCompletada() {
        return completada;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }
    
}
