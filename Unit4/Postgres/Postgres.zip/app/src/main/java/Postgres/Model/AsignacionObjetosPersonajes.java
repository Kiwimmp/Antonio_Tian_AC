package Postgres.Model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "asignacion_objetos_personajes")
public class AsignacionObjetosPersonajes implements Serializable {

    @Id
    @ManyToOne
    @JoinColumn(name = "personaje_id")
    private Personaje personaje;

    @Id
    @ManyToOne
    @JoinColumn(name = "objeto_id")
    private Objeto objeto;

    // Constructor

    public AsignacionObjetosPersonajes() {
    }

    public AsignacionObjetosPersonajes(Personaje personaje, Objeto objeto) {
        this.personaje = personaje;
        this.objeto = objeto;
    }
    
    //Getters y setters

    public Personaje getPersonaje() {
        return personaje;
    }

    public void setPersonaje(Personaje personaje) {
        this.personaje = personaje;
    }

    public Objeto getObjeto() {
        return objeto;
    }

    public void setObjeto(Objeto objeto) {
        this.objeto = objeto;
    }
    

}
