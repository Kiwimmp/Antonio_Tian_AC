package Postgres.Model;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Mago extends Personaje {

    @Column(name = "arma")
    private String arma;

    public Mago() {

    }

    public Mago(String nombre, int nivel, Personaje.Clase_personaje clase, String arma) {
        super(nombre, nivel, clase);
        this.arma = arma;
    }

    public String getArma() {
        return arma;
    }

    public void setArma(String arma) {
        this.arma = arma;
    }
}
