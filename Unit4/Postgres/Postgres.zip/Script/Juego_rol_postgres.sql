-- Crear la base de datos
CREATE database juego_rol;

-- Crear el tipo de dato para la dirección
CREATE TYPE direccion AS (
    calle VARCHAR(50),
    ciudad VARCHAR(50),
    pais VARCHAR(50)
);
-- Crear nuevo tipo de dato
create type clase_jugador as enum ('Melee','Rango','Arcane');

-- Crear el tipo de dato enum para la rareza de objetos
CREATE TYPE rareza AS ENUM ('Común', 'Poco Común', 'Raro', 'Épico', 'Legendario');

-- Crear el tipo de dato para el tipo de arma
CREATE TYPE tipo_arma AS ENUM ('Melee', 'Rango', 'Bastón');

-- Crear el tipo de dato para la habilidad
CREATE TYPE habilidad AS (
    nombre VARCHAR(50)
);

-- Crear el tipo de dato para los atributos del personaje
CREATE TYPE atributos_personaje AS (
    vida INTEGER ,
    mana INTEGER ,
    ataque INTEGER ,
    defensa INTEGER ,
    velocidad_movimiento INTEGER,
    velocidad_ataque INTEGER
);


-- Crear la tabla de jugadores
CREATE TABLE jugadores (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    correo VARCHAR(100) NOT NULL,
    direccion_jugador direccion
);

-- Crear la tabla de personajes
CREATE TABLE personajes (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    nivel INT,
    clase clase_jugador,
    jugador_id INT,
    atributos atributos_personaje default row(100,30,10,10,10,1),
    FOREIGN KEY (jugador_id) REFERENCES jugadores(id)
);

-- Crear la tabla de objetos
CREATE TABLE objetos (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    tipo tipo_arma,
    rareza rareza
);

-- Crear la tabla de misiones
CREATE TABLE misiones (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    tipo VARCHAR(50),
    dificultad VARCHAR(20)
);

-- Crear la tabla de asignación de objetos a personajes
CREATE TABLE asignacion_objetos_personajes (
    personaje_id INT,
    objeto_id INT,
    PRIMARY KEY (personaje_id, objeto_id),
    FOREIGN KEY (personaje_id) REFERENCES personajes(id),
    FOREIGN KEY (objeto_id) REFERENCES objetos(id)
);

-- Crear la tabla de asignación de misiones a personajes
CREATE TABLE asignacion_misiones_personajes (
    personaje_id INT,
    mision_id INT,
    completada BOOLEAN,
    PRIMARY KEY (personaje_id, mision_id),
    FOREIGN KEY (personaje_id) REFERENCES personajes(id),
    FOREIGN KEY (mision_id) REFERENCES misiones(id)
);

-- Crear las tablas para los roles específicos
CREATE TABLE guerreros (
    id INT PRIMARY KEY REFERENCES personajes(id),
    melee VARCHAR(50) NOT NULL
) INHERITS (personajes);

CREATE TABLE magos (
    id INT PRIMARY KEY REFERENCES personajes(id),
    baston VARCHAR(50) NOT NULL
) INHERITS (personajes);

CREATE TABLE tiradores (
    id INT PRIMARY KEY REFERENCES personajes(id),
    rango VARCHAR(50) NOT NULL
) INHERITS (personajes);
