-- Crear la base de datos
CREATE DATABASE if not exists juego_rol;

-- Usar la base de datos
USE juego_rol;

-- Crear la tabla de jugadores
CREATE TABLE jugadores (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    correo VARCHAR(100) NOT NULL
);

-- Crear la tabla de personajes
-- Esta tabla hereda de jugadores
CREATE TABLE personajes (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    nivel INT,
    clase VARCHAR(50),
    jugador_id INT,
    FOREIGN KEY (jugador_id) REFERENCES jugadores(id)
);

-- Crear la tabla de objetos
CREATE TABLE objetos (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    tipo VARCHAR(50),
    rareza VARCHAR(20)
);

-- Crear la tabla de misiones
CREATE TABLE misiones (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    tipo VARCHAR(50),
    dificultad VARCHAR(20)
);

-- Crear la tabla de asignación de objetos a personajes
CREATE TABLE asignacion_objetos_personajes (
    personaje_id INT,
    objeto_id INT,
    PRIMARY KEY (personaje_id, objeto_id),
    FOREIGN KEY (personaje_id) REFERENCES personajes(id),
    FOREIGN KEY (objeto_id) REFERENCES objetos(id)
);

-- Crear la tabla de asignación de misiones a personajes
CREATE TABLE asignacion_misiones_personajes (
    personaje_id INT,
    mision_id INT,
    completada BOOLEAN,
    PRIMARY KEY (personaje_id, mision_id),
    FOREIGN KEY (personaje_id) REFERENCES personajes(id),
    FOREIGN KEY (mision_id) REFERENCES misiones(id)
);


-- Creacion de nuevos tipos 
-- Crear nuevo tipo de dato
create type atributos_personaje as(
    vida INT DEFAULT 100,
    mana INT DEFAULT 30,
    ataque INT DEFAULT 10,
    defensa INT DEFAULT 10,
    velocidad_movimiento INT DEFAULT 10,
    velocidad_ataque INT DEFAULT 1
);

-- Crear nuevo tipo de dato
create type clase_jugador as enum ('Guerrero','Mago','Tirador');

-- Crear tipo de dato para la direccion de un jugador
create type direccion as (
	calle varchar (50),
	ciudad varchar (50),
	pais varchar (50)
);
-- Crear tipo de dato enum para la rareza de Objectos
create type rareza as enum( 'Común','Poco Común','Raro','Epico','Legendario');

-- Crear nuevo tipo de dato para tipo de objecto
create type tipo_arma as enum ('Melee','Rango','Baston');


-- Añadir o modificar las tablas
-- Añadir nueva columna de direccion
alter table jugadores
add column direccion_jugador direccion;

-- Cambiar la columna de rareza al nuevo tipo de dato
alter table objectos
add column rareza TYPE rareza_objecto;

-- Cambiar la columna de tipo, de la tabla de objectos
alter table objectos
add column tipo type tipo_arma;

-- Cambiar la columa id de personaje a autocremento
alter table personajes
add column id type serial;

-- Cambiar la columa id de objetos a autocremento
alter table objetos
add column id type serial;

-- Cambiar la columa id de jugadores a autocremento
alter table jugadores
add column id type serial;

-- Cambiar la columa id de misiones a autocremento
alter table misiones
add column id type serial;

-- Cambiar la columna de clase, de la tabla de Personaje
alter table personajes
add column clase type clase_jugador;

-- Añadir la columna de atributos a la tabla de Personaje
alter table personajes
add column atributos type atributos_personaje;


-- Crear nuevos roles que heredan de personaje
-- Crear tabla para guerreros
CREATE TABLE guerreros (
    id INT PRIMARY KEY REFERENCES personajes(id),
    arma VARCHAR(50) NOT NULL
)inherits (personajes);

-- Crear tabla para magos
CREATE TABLE magos (
    id INT PRIMARY KEY REFERENCES personajes(id),
    baston VARCHAR(50) NOT NULL
)inherits (personajes);

-- Crear tabla para tiradores
CREATE TABLE tiradores (
    id INT PRIMARY KEY REFERENCES personajes(id),
    arco VARCHAR(50) NOT NULL
)inherits (personajes);






