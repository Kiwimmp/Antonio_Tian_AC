-- Crear la base de datos
CREATE DATABASE if not exists juego_rol;

-- Usar la base de datos
USE juego_rol;

-- Crear la tabla de jugadores
CREATE TABLE jugadores (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    correo VARCHAR(100) NOT NULL
);

-- Crear la tabla de personajes
CREATE TABLE personajes (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    nivel INT,
    clase VARCHAR(50),
    jugador_id INT,
    FOREIGN KEY (jugador_id) REFERENCES jugadores(id)
);

-- Crear la tabla de objetos
CREATE TABLE objetos (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    tipo VARCHAR(50),
    rareza VARCHAR(20)
);

-- Crear la tabla de misiones
CREATE TABLE misiones (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    tipo VARCHAR(50),
    dificultad VARCHAR(20)
);

-- Crear la tabla de asignación de objetos a personajes
CREATE TABLE asignacion_objetos_personajes (
    personaje_id INT,
    objeto_id INT,
    PRIMARY KEY (personaje_id, objeto_id),
    FOREIGN KEY (personaje_id) REFERENCES personajes(id),
    FOREIGN KEY (objeto_id) REFERENCES objetos(id)
);

-- Crear la tabla de asignación de misiones a personajes
CREATE TABLE asignacion_misiones_personajes (
    personaje_id INT,
    mision_id INT,
    completada BOOLEAN,
    PRIMARY KEY (personaje_id, mision_id),
    FOREIGN KEY (personaje_id) REFERENCES personajes(id),
    FOREIGN KEY (mision_id) REFERENCES misiones(id)
);

-- Insertar jugadores
INSERT INTO jugadores (id, nombre, correo) VALUES
(1, 'Jugador1', 'jugador1@email.com'),
(2, 'Jugador2', 'jugador2@email.com');

-- Insertar personajes
INSERT INTO personajes (id, nombre, nivel, clase, jugador_id) VALUES
(1, 'Guerrero1', 5, 'Guerrero', 1),
(2, 'Mago1', 3, 'Mago', 1),
(3, 'Explorador1', 4, 'Explorador', 2);

-- Insertar objetos
INSERT INTO objetos (id, nombre, tipo, rareza) VALUES
(1, 'Espada Mágica', 'Arma', 'Épica'),
(2, 'Poción de Curación', 'Consumible', 'Común');

-- Insertar misiones
INSERT INTO misiones (id, nombre, tipo, dificultad) VALUES
(1, 'Salvar la Aldea', 'Principal', 'Difícil'),
(2, 'Recoger Hierbas', 'Secundaria', 'Fácil');

-- Asignar objetos a personajes
INSERT INTO asignacion_objetos_personajes (personaje_id, objeto_id) VALUES
(1, 1),
(2, 2),
(3, 1);

-- Asignar misiones a personajes
INSERT INTO asignacion_misiones_personajes (personaje_id, mision_id, completada) VALUES
(1, 1, false),
(1, 2, true),
(3, 2, false);

